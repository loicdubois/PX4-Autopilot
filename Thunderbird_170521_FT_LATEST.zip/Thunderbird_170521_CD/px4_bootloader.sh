st-flash write omnibusf4sd_bl.bin 0x8000000
